const button = document.querySelector('.button-add-task');
const input = document.querySelector('.input-task');
const listaCompleta = document.querySelector('.list-task');

let minhaListaDeItens = [];

function adicionarNovaTarefa() {
    const textoTarefa = input.value.trim();
    if (textoTarefa === '') return;

    const posicaoEmEdicao = input.dataset.posicao;

    if (posicaoEmEdicao !== undefined) {
        minhaListaDeItens[posicaoEmEdicao].tarefa = textoTarefa;
        input.removeAttribute('data-posicao');
    } else {
        minhaListaDeItens.push({
            tarefa: textoTarefa,
            concluida: false
        });
    }

    input.value = '';
    mostrarTarefas();
}

function mostrarTarefas() {
    let novaLi = '';

    minhaListaDeItens.forEach((item, posicao) => {
        novaLi += `
            <li class="task ${item.concluida ? 'done' : ''}">
                <img src="./img/png-transparent-check-mark-cheque-check-miscellaneous-angle-text-thumbnail-removebg-preview.png" alt="check-na-tarefa" onclick="concluirTarefa(${posicao})">
                <p>${item.tarefa}</p>
                <img src="./img/lixeira-removebg-preview.png" alt="tarefa-para-o-lixo" onclick="deletarItem(${posicao})">
                <img src="./img/edit.png.png" alt="editar-tarefa" onclick="editarTarefa(${posicao})">
            </li>
        `;
    });

    listaCompleta.innerHTML = novaLi;
    localStorage.setItem('lista', JSON.stringify(minhaListaDeItens));
}

function concluirTarefa(posicao) {
    minhaListaDeItens[posicao].concluida = !minhaListaDeItens[posicao].concluida;
    mostrarTarefas();
}

function deletarItem(posicao) {
    minhaListaDeItens.splice(posicao, 1);
    mostrarTarefas();
}

function recarregarTarefas() {
    const TarefasDoLocalStorage = localStorage.getItem('lista');
    if (TarefasDoLocalStorage) {
        minhaListaDeItens = JSON.parse(TarefasDoLocalStorage);
    }
    mostrarTarefas();
}
recarregarTarefas();

function editarTarefa(posicao) {
    const tarefaEditavel = minhaListaDeItens[posicao];
    input.value = tarefaEditavel.tarefa;
    input.dataset.posicao = posicao;
}

const buttonToggle = document.querySelector('.button-toggle');

buttonToggle.addEventListener('click', function() {
    const tasksConcluidas = document.querySelectorAll('.task.done');
    tasksConcluidas.forEach(task => {
        task.style.display = task.style.display === 'none' ? '' : 'none';
    });
});

button.addEventListener('click', adicionarNovaTarefa);
